�
 2tsXhrBFrontend-main/pingo/src/components/game/InitialDialogComponent.tsx